# ModbusManager Pro — Siemens S7-1200 demo

A Siemens S7-1200 acting as a **Modbus TCP server** (slave), running a simulated
solar inverter. ModbusManager Pro polls it and shows the data live on a Dashboard HMI.

No extra hardware: the S7-1200 handles Modbus TCP through its onboard Ethernet port.

---

## Holding register map

All addresses are **0-based** (Modbus 40001 = address 0). 32-bit values use
**big-endian word order** (high word at the lower address).

| Addr | 4xxxx | Value | Type | Scale | Unit | Widget |
|-----:|------:|-------|------|-------|------|--------|
| 0  | 40001 | AC active power      | INT (s16)  | ÷10  | kW  | Gauge 0–50 |
| 1  | 40002 | DC voltage           | INT (s16)  | ÷1   | V   | KPI |
| 2  | 40003 | DC current           | INT (s16)  | ÷10  | A   | KPI |
| 3  | 40004 | Grid frequency       | INT (s16)  | ÷100 | Hz  | KPI |
| 4  | 40005 | Inverter temperature | INT (s16)  | ÷10  | °C  | Gauge / bar |
| 5–6 | 40006–40007 | Daily energy yield | U32 (hi,lo) | ÷100 | kWh | KPI |
| 7–8 | 40008–40009 | Total energy yield | U32 (hi,lo) | ÷1   | kWh | KPI |
| 9  | 40010 | DC string 1 current  | INT (s16)  | ÷10  | A   | Trend |
| 10 | 40011 | Battery SOC          | INT (s16)  | ÷1   | %   | Bar / tank |
| 11 | 40012 | Status word          | WORD       | bits | —   | Lamps |

**Status word bits (register 40012):**

| Bit | Meaning |
|----:|---------|
| 0 | Grid-connected / running |
| 1 | Fault (stays 0 in normal demo) |
| 2 | Derating active (temp > 52 °C) |
| 3 | Standby / night |

> "Scale ÷10" means the register holds the value × 10. Read 423 → 42.3 kW.
> Apply these divisors in the ModbusManager Pro tag engine.

---

## TIA Portal setup (S7-1200)

1. **New project** → add your exact S7-1200 CPU (match the order number / firmware).
2. **Set the CPU IP**, e.g. `192.168.0.1 / 255.255.255.0`
   (Device view → PROFINET interface → Ethernet addresses).
3. **Import the logic:** Project tree → *External source files* →
   *Add new external file* → select `SolarInverterDemo.scl`.
   Then right-click the imported source → **Generate blocks from source**.
   This creates the global DB `MB_HoldingReg` and the FB `SolarInverterDemo`.
4. **Call the FB in OB1.** Open *Main [OB1]* and add a call to `SolarInverterDemo`.
   When prompted, let TIA create the instance DB (`SolarInverterDemo_DB`). In SCL:
   ```
   "SolarInverterDemo_DB"(Enable := TRUE);
   ```
   (In LAD/FBD: drag the FB into a network and confirm the instance DB.)
5. **Compile** the whole project, then **download to the PLC**.

That's it — `MB_SERVER` listens passively on TCP port 502 for any client.

---

## Test from a PC

1. Put your PC on the same subnet, e.g. `192.168.0.10 / 255.255.255.0`.
   Ping the PLC to confirm the link.
2. In ModbusManager, add a **Modbus TCP** connection:
   - Host: the PLC IP (`192.168.0.1`)
   - Port: `502`
   - Unit / Slave ID: `1`
3. Add a poll window: **Read Holding Registers (FC03)**, start address `0`, length `12`.
4. You should see the values changing as the simulated day runs.

---

## Common gotchas

- `MB_HoldingReg` **must be non-optimized access** (already set in the `.scl`).
  Optimized access breaks the contiguous register area `MB_SERVER` expects.
- `MB_SERVER` **must run every scan** — keep the FB call in OB1, not in a one-shot.
- Modbus addressing is **0-based**: 40001 = address 0. If a tool shows nothing,
  check whether it expects 1-based addresses.
- Same subnet + port 502 reachable (no firewall blocking TCP/502).
- If your TIA shows a `CONNECT` parameter on `MB_SERVER` instead of
  `CONNECT_ID` + `IP_PORT`, you have an older instruction interface — tell me and
  I'll give you the matching `TCON_IP_v4` connection-DB version.

---

## Next step

Once you can poll the 12 registers, the matching **ModbusManager Pro workspace**
(`.json`) is built around this exact map — poll window + tags (with the divisors
above and the two U32 word-pairs decoded) + a Dashboard page with gauge, KPIs,
SOC bar, power trend, and status lamps.
